package cn.rzpt.domain.role.service;

import cn.rzpt.domain.role.model.req.RolePageReq;
import cn.rzpt.domain.role.model.vo.RoleVO;

import java.util.List;

public interface IRoleExec {

    List<RoleVO> roleList(RolePageReq req);

}
