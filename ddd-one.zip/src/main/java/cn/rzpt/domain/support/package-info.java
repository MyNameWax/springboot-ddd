/**
 * 支持领域层运行的（可以放置Id生成器（因为可能领域层需要））
 * 也可以放置RedisConfig（因为领域层用到了）
 */
package cn.rzpt.domain.support;
