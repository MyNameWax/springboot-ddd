package cn.rzpt.domain.support.ids;

public interface IIdGenerator {
    long nextId();
}
