/**
 * 放置工具类: 比如RedisUtil
 */
package cn.rzpt.infrastructure.util;
