package cn.rzpt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DddOneApplicationTests {

    @Test
    void contextLoads() {
    }

}
